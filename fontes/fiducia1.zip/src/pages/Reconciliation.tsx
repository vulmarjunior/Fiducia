import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, writeBatch } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select as ShadcnSelect, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { parseOFX, ImportedTransaction } from '../lib/ofxParser';
import Papa from 'papaparse';
import { format, parseISO, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Check, X, Link as LinkIcon, Plus, CheckCircle2, AlertCircle, LayoutDashboard, Download, FileText } from 'lucide-react';
import { calculateInvoicePeriod, resolveAccountName } from '../lib/utils';

export function Reconciliation() {
  const { user, isAuthReady } = useAuth();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [creditCards, setCreditCards] = useState<any[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [systemTransactions, setSystemTransactions] = useState<any[]>([]);
  const [importedTransactions, setImportedTransactions] = useState<ImportedTransaction[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  
  const [selectedImportedId, setSelectedImportedId] = useState<string | null>(null);
  const [selectedSystemId, setSelectedSystemId] = useState<string | null>(null);

  useEffect(() => {
    if (!isAuthReady || !user) return;

    const accountsQuery = query(collection(db, 'accounts'), where('userId', '==', user.uid));
    const unsubscribeAccounts = onSnapshot(accountsQuery, (snapshot) => {
      setAccounts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    const creditCardsQuery = query(collection(db, 'creditCards'), where('userId', '==', user.uid));
    const unsubscribeCreditCards = onSnapshot(creditCardsQuery, (snapshot) => {
      setCreditCards(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubscribeAccounts();
      unsubscribeCreditCards();
    };
  }, [user, isAuthReady]);

  useEffect(() => {
    if (!isAuthReady || !user || !selectedAccountId) {
      setSystemTransactions([]);
      return;
    }

    const isCreditCard = creditCards.some(cc => cc.id === selectedAccountId);
    
    // Fetch pending transactions for the selected account
    const txQuery = query(
      collection(db, 'transactions'),
      where('userId', '==', user.uid),
      where(isCreditCard ? 'creditCardId' : 'accountId', '==', selectedAccountId),
      where('reconciliationStatus', 'in', ['nao_conciliado', null])
    );

    const unsubscribeTx = onSnapshot(txQuery, (snapshot) => {
      // Also filter out transactions that are already reconciled in case the query doesn't catch nulls properly
      const txs = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .filter((t: any) => !t.reconciliationStatus || t.reconciliationStatus === 'nao_conciliado');
      
      // Sort by date descending
      txs.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setSystemTransactions(txs);
    });

    return () => unsubscribeTx();
  }, [user, isAuthReady, selectedAccountId, creditCards]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      const content = e.target?.result as string;
      
      if (file.name.toLowerCase().endsWith('.ofx')) {
        const parsed = parseOFX(content);
        setImportedTransactions(parsed);
        toast.success(`${parsed.length} transações importadas do OFX.`);
      } else if (file.name.toLowerCase().endsWith('.csv')) {
        Papa.parse(content, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            // Simple CSV parser assuming Date, Amount, Description columns
            // You might need to adjust this based on the actual CSV format
            const parsed: ImportedTransaction[] = results.data.map((row: any, index) => {
              const dateStr = row.Date || row.Data || row.date || row.data;
              const amountStr = row.Amount || row.Valor || row.amount || row.valor;
              const descStr = row.Description || row.Descricao || row.description || row.descricao || row.Memo || row.memo;
              
              let amount = 0;
              if (amountStr) {
                amount = parseFloat(amountStr.replace(',', '.'));
              }
              
              let date = new Date().toISOString();
              if (dateStr) {
                // Try to parse DD/MM/YYYY
                const parts = dateStr.split('/');
                if (parts.length === 3) {
                  date = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T12:00:00Z`).toISOString();
                } else {
                  date = new Date(dateStr).toISOString();
                }
              }

              return {
                id: `csv-${index}-${Date.now()}`,
                date,
                amount: Math.abs(amount),
                description: descStr || 'Transação Importada',
                type: amount >= 0 ? 'receita' : 'despesa',
                status: 'pending'
              };
            });
            setImportedTransactions(parsed);
            toast.success(`${parsed.length} transações importadas do CSV.`);
          },
          error: (error) => {
            toast.error(`Erro ao ler CSV: ${error.message}`);
          }
        });
      } else {
        toast.error('Formato de arquivo não suportado. Use OFX ou CSV.');
      }
      setIsUploading(false);
      // Reset file input
      event.target.value = '';
    };

    reader.onerror = () => {
      toast.error('Erro ao ler o arquivo.');
      setIsUploading(false);
    };

    reader.readAsText(file);
  };

  const autoReconcile = () => {
    let matchCount = 0;
    const newImported = [...importedTransactions];
    const matchedSystemIds = new Set<string>();

    newImported.forEach(impTx => {
      if (impTx.status !== 'pending') return;

      // Find a matching system transaction
      const match = systemTransactions.find(sysTx => {
        if (matchedSystemIds.has(sysTx.id)) return false;
        
        // Match criteria: Same type, same amount, date within 3 days
        const isSameType = (sysTx.type === 'receita' || sysTx.type === 'income') === (impTx.type === 'receita');
        const isSameAmount = Math.abs(sysTx.amount - impTx.amount) < 0.01;
        
        const sysDate = parseISO(sysTx.date);
        const impDate = parseISO(impTx.date);
        const daysDiff = Math.abs(differenceInDays(sysDate, impDate));
        
        return isSameType && isSameAmount && daysDiff <= 3;
      });

      if (match) {
        impTx.status = 'matched';
        impTx.matchedWithSystemId = match.id;
        matchedSystemIds.add(match.id);
        matchCount++;
      }
    });

    setImportedTransactions(newImported);
    toast.success(`${matchCount} transações conciliadas automaticamente.`);
  };

  const manualMatch = () => {
    if (!selectedImportedId || !selectedSystemId) {
      toast.error('Selecione uma transação importada e uma do sistema para conciliar.');
      return;
    }

    setImportedTransactions(prev => prev.map(tx => 
      tx.id === selectedImportedId 
        ? { ...tx, status: 'matched', matchedWithSystemId: selectedSystemId } 
        : tx
    ));
    
    setSelectedImportedId(null);
    setSelectedSystemId(null);
    toast.success('Transações conciliadas manualmente.');
  };

  const ignoreImported = (id: string) => {
    setImportedTransactions(prev => prev.map(tx => 
      tx.id === id ? { ...tx, status: 'ignored' } : tx
    ));
    if (selectedImportedId === id) setSelectedImportedId(null);
  };

  const unmatchImported = (id: string) => {
    setImportedTransactions(prev => prev.map(tx => 
      tx.id === id ? { ...tx, status: 'pending', matchedWithSystemId: undefined } : tx
    ));
    if (selectedImportedId === id) setSelectedImportedId(null);
  };

  const addAsNewTransaction = async (impTx: ImportedTransaction) => {
    if (!user || !selectedAccountId) return;

    const isCreditCard = creditCards.some(cc => cc.id === selectedAccountId);
    const card = creditCards.find(cc => cc.id === selectedAccountId);
    
    const newTx = {
      userId: user.uid,
      amount: impTx.amount,
      date: impTx.date,
      description: impTx.description,
      type: impTx.type,
      status: isCreditCard ? 'realizado' : 'pago',
      reconciliationStatus: 'conciliado',
      categoryId: 'default', // Default category for imported transactions
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as any;

    if (isCreditCard && card) {
      newTx.creditCardId = selectedAccountId;
      newTx.invoicePeriod = calculateInvoicePeriod(impTx.date, card.closingDay, card.dueDay);
    } else {
      newTx.accountId = selectedAccountId;
    }

    try {
      const batch = writeBatch(db);
      const newTxRef = doc(collection(db, 'transactions'));
      batch.set(newTxRef, newTx);
      
      // Update account balance if it's a checking account and status is 'pago'
      if (!isCreditCard) {
        const acc = accounts.find(a => a.id === selectedAccountId);
        if (acc) {
          const balanceChange = impTx.type === 'receita' ? impTx.amount : -impTx.amount;
          batch.update(doc(db, 'accounts', acc.id), { balance: (acc.balance || 0) + balanceChange });
        }
      }

      await batch.commit();

      // Mark imported as added
      setImportedTransactions(prev => prev.map(tx => 
        tx.id === impTx.id ? { ...tx, status: 'added', matchedWithSystemId: newTxRef.id } : tx
      ));
      
      if (selectedImportedId === impTx.id) setSelectedImportedId(null);
      toast.success('Nova transação adicionada e conciliada.');
    } catch (error) {
      console.error("Error adding transaction:", error);
      toast.error('Erro ao adicionar transação.');
    }
  };

  const finalizeReconciliation = async () => {
    if (!user || !selectedAccountId) return;

    const matchedTransactions = importedTransactions.filter(tx => tx.status === 'matched' && tx.matchedWithSystemId);
    
    if (matchedTransactions.length === 0) {
      toast.error('Nenhuma transação conciliada para finalizar.');
      return;
    }

    try {
      const batch = writeBatch(db);
      
      // Update all matched system transactions
      matchedTransactions.forEach(impTx => {
        if (impTx.matchedWithSystemId) {
          batch.update(doc(db, 'transactions', impTx.matchedWithSystemId), {
            reconciliationStatus: 'conciliado',
            updatedAt: new Date().toISOString()
          });
        }
      });

      // Create reconciliation history record
      const historyRef = doc(collection(db, 'reconciliationHistory'));
      
      // Find date range
      const dates = importedTransactions.map(t => new Date(t.date).getTime());
      const minDate = new Date(Math.min(...dates)).toISOString();
      const maxDate = new Date(Math.max(...dates)).toISOString();

      batch.set(historyRef, {
        userId: user.uid,
        accountId: selectedAccountId,
        periodStart: minDate,
        periodEnd: maxDate,
        reconciledAt: new Date().toISOString()
      });

      await batch.commit();
      
      // Clear imported transactions
      setImportedTransactions([]);
      setSelectedImportedId(null);
      setSelectedSystemId(null);
      
      toast.success('Conciliação finalizada com sucesso!');
    } catch (error) {
      console.error("Error finalizing reconciliation:", error);
      toast.error('Erro ao finalizar conciliação.');
    }
  };

  const pendingImported = importedTransactions.filter(t => t.status === 'pending');
  const matchedImported = importedTransactions.filter(t => t.status === 'matched' || t.status === 'added');
  const ignoredImported = importedTransactions.filter(t => t.status === 'ignored');

  // Filter out system transactions that are already matched in the current session
  const matchedSystemIdsInSession = new Set(importedTransactions.filter(t => t.status === 'matched').map(t => t.matchedWithSystemId));
  const availableSystemTransactions = systemTransactions.filter(t => !matchedSystemIdsInSession.has(t.id));

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Conciliação</h1>
          <p className="text-gray-500 mt-1">Importe seu extrato e concilie com os lançamentos do sistema.</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="w-64">
            <ShadcnSelect value={selectedAccountId} onValueChange={setSelectedAccountId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma conta">
                  {selectedAccountId ? resolveAccountName(selectedAccountId, accounts, creditCards) : 'Selecione uma conta'}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Contas Correntes</SelectLabel>
                  {accounts.map(a => (
                    <SelectItem key={a.id} value={a.id}>{resolveAccountName(a.id, accounts, creditCards)}</SelectItem>
                  ))}
                </SelectGroup>
                {creditCards.length > 0 && (
                  <SelectGroup>
                    <SelectLabel>Cartões de Crédito</SelectLabel>
                    {creditCards.map(c => (
                      <SelectItem key={c.id} value={c.id}>{resolveAccountName(c.id, accounts, creditCards)}</SelectItem>
                    ))}
                  </SelectGroup>
                )}
              </SelectContent>
            </ShadcnSelect>
          </div>
          
          <div>
            <Input 
              type="file" 
              accept=".ofx,.csv" 
              onChange={handleFileUpload} 
              disabled={!selectedAccountId || isUploading}
              className="cursor-pointer"
              id="file-upload"
            />
          </div>
        </div>
      </div>

      {importedTransactions.length > 0 && (
        <div className="flex items-center justify-between bg-white p-4 rounded-xl border shadow-sm">
          <div className="flex gap-6">
            <div className="text-center">
              <p className="text-sm text-gray-500 font-medium">Total Importado</p>
              <p className="text-2xl font-bold">{importedTransactions.length}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-500 font-medium">Pendentes</p>
              <p className="text-2xl font-bold text-amber-500">{pendingImported.length}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-500 font-medium">Conciliados</p>
              <p className="text-2xl font-bold text-green-500">{matchedImported.length}</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button variant="outline" onClick={autoReconcile} disabled={pendingImported.length === 0}>
              Conciliar Automaticamente
            </Button>
            <Button onClick={finalizeReconciliation} disabled={matchedImported.length === 0} className="bg-fiducia-blue hover:bg-fiducia-blue/90">
              Finalizar Conciliação
            </Button>
          </div>
        </div>
      )}

      {importedTransactions.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Imported Transactions */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Download className="h-5 w-5 text-gray-400" />
              Extrato Importado
            </h2>
            
            <div className="bg-white rounded-xl border shadow-sm overflow-hidden flex flex-col h-[600px]">
              <div className="overflow-y-auto flex-1 p-2 space-y-2">
                {importedTransactions.map(tx => (
                  <div 
                    key={tx.id}
                    onClick={() => tx.status === 'pending' && setSelectedImportedId(tx.id === selectedImportedId ? null : tx.id)}
                    className={`p-4 rounded-lg border transition-all ${
                      tx.status === 'matched' || tx.status === 'added' ? 'bg-green-50 border-green-200 opacity-60' :
                      tx.status === 'ignored' ? 'bg-gray-50 border-gray-200 opacity-50' :
                      selectedImportedId === tx.id ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-200 cursor-pointer' :
                      'bg-white border-gray-200 hover:border-blue-300 cursor-pointer'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-medium text-gray-900">{tx.description}</div>
                      <div className={`font-mono font-semibold ${tx.type === 'receita' ? 'text-green-600' : 'text-red-600'}`}>
                        {tx.type === 'receita' ? '+' : '-'}R$ {tx.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-500">
                      <div>{format(parseISO(tx.date), "dd 'de' MMM, yyyy", { locale: ptBR })}</div>
                      
                      {tx.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-gray-500 hover:text-red-600" onClick={(e) => { e.stopPropagation(); ignoreImported(tx.id); }}>
                            <X className="h-4 w-4 mr-1" /> Ignorar
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-gray-500 hover:text-green-600" onClick={(e) => { e.stopPropagation(); addAsNewTransaction(tx); }}>
                            <Plus className="h-4 w-4 mr-1" /> Adicionar
                          </Button>
                        </div>
                      )}
                      
                      {(tx.status === 'matched' || tx.status === 'added') && (
                        <div className="flex items-center text-green-600 font-medium gap-1">
                          <CheckCircle2 className="h-4 w-4" /> Conciliado
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0 ml-2 text-gray-400 hover:text-red-500" onClick={(e) => { e.stopPropagation(); unmatchImported(tx.id); }}>
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      
                      {tx.status === 'ignored' && (
                        <div className="flex items-center text-gray-400 font-medium gap-1">
                          <AlertCircle className="h-4 w-4" /> Ignorado
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0 ml-2 text-gray-400 hover:text-blue-500" onClick={(e) => { e.stopPropagation(); unmatchImported(tx.id); }}>
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: System Transactions */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <LayoutDashboard className="h-5 w-5 text-gray-400" />
                Lançamentos do Sistema
              </h2>
              
              {selectedImportedId && selectedSystemId && (
                <Button size="sm" onClick={manualMatch} className="bg-fiducia-blue hover:bg-fiducia-blue/90 animate-in fade-in zoom-in duration-200">
                  <LinkIcon className="h-4 w-4 mr-2" />
                  Vincular Selecionados
                </Button>
              )}
            </div>
            
            <div className="bg-white rounded-xl border shadow-sm overflow-hidden flex flex-col h-[600px]">
              <div className="overflow-y-auto flex-1 p-2 space-y-2">
                {availableSystemTransactions.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-gray-400 p-8 text-center">
                    <CheckCircle2 className="h-12 w-12 mb-4 text-gray-200" />
                    <p>Não há lançamentos pendentes de conciliação para esta conta no sistema.</p>
                  </div>
                ) : (
                  availableSystemTransactions.map(tx => (
                    <div 
                      key={tx.id}
                      onClick={() => setSelectedSystemId(tx.id === selectedSystemId ? null : tx.id)}
                      className={`p-4 rounded-lg border transition-all cursor-pointer ${
                        selectedSystemId === tx.id ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-200' :
                        'bg-white border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="font-medium text-gray-900">{tx.description}</div>
                        <div className={`font-mono font-semibold ${tx.type === 'receita' || tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                          {tx.type === 'receita' || tx.type === 'income' ? '+' : '-' }R$ {tx.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-sm text-gray-500">
                        <div>{format(parseISO(tx.date), "dd 'de' MMM, yyyy", { locale: ptBR })}</div>
                        <div className="flex gap-2">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium uppercase tracking-wider ${
                            tx.status === 'pago' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {tx.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-dashed border-gray-300 p-12 text-center flex flex-col items-center justify-center min-h-[400px]">
          <div className="h-20 w-20 bg-gray-50 rounded-full flex items-center justify-center mb-6">
            <FileText className="h-10 w-10 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Nenhum extrato importado</h3>
          <p className="text-gray-500 max-w-md mb-8">
            Selecione uma conta e faça o upload de um arquivo OFX ou CSV do seu banco para iniciar a conciliação.
          </p>
          <Button onClick={() => document.getElementById('file-upload')?.click()} disabled={!selectedAccountId} className="bg-fiducia-blue hover:bg-fiducia-blue/90">
            Selecionar Arquivo
          </Button>
        </div>
      )}
    </div>
  );
}
